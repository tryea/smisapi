<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
 
// get database connection
include_once '../config/database.php';
 
// instantiate product object
include_once '../objects/product.php';
 
$database = new Database();
$db = $database->getConnection();
 
$product = new Product($db);
 
// query products
$id = $_GET['id'];
$stmt = $product->productDetailInfoPerId($id);
$num = $stmt->rowCount();

if($num>0){
    $productDetail_arr=array();
    $productDetail_arr["records"]= array();
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        extract($row);
        $path = "http://ersaptaaristo.xyz/uploads/" . "product_" . $product_id . "_" . $product_detail_id . "_" . $product_detail_name . ".jpg";
        $current_product_detail = array(
            "productDetailId" => $product_detail_id,
            "productDetailName" => $product_detail_name,
            "colour" => $colour,
            "size" => $size,
            "stock" => $stock,
            "categoryName" => $category_name,
            "productName" => $product_name,
            "price" => $price,
            "imagePath" => $path
        );
        array_push($productDetail_arr["records"], $current_product_detail);
    }

    http_response_code(200);
    echo json_encode($productDetail_arr);
}
else{
    http_response_code(404);
    echo json_encode(array("message" => "No products found."));
}

?>